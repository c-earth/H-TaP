import numpy as np
import matplotlib.pyplot as plt
import math

dE = np.linspace(-50, 50, 1001)
dE1 = -40
dE2 = 24
pi = math.pi
d = 1.5e-5

ec = 8/(3*pi**2*d**3)*(((dE-dE1)**3+(dE1)**3)+2*((dE-dE2)**3+(dE2)**3))

fig, ax = plt.subplots(1, 1, figsize = (14, 7), dpi=300)
ax.plot(dE, ec, 'r-')
ax.axvline(x = 0, linewidth = 1, color = 'k', linestyle = (0, (8, 10)))
ax.axhline(y = 0, linewidth = 1, color = 'k', linestyle = (0, (8, 10)))
ax.set_xlabel(r'$E-E_f$ [meV]', fontsize = 24)
ax.set_ylabel(r'Doped Electron [cm$^{-3}$]', fontsize = 24)
ax.tick_params(axis = 'both', which = 'both', width = 2, length = 10, direction = 'in', labelsize = 24)
ax.yaxis.get_offset_text().set_size(24)
# plt.show()
plt.savefig('TaP_model.png')